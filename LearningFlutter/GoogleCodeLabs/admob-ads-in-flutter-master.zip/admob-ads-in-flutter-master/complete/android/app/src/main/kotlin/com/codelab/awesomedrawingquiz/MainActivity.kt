package com.codelab.awesomedrawingquiz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}