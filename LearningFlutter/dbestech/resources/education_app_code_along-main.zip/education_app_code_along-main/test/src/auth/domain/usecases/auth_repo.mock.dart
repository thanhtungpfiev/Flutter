import 'package:education_app/src/auth/domain/repos/auth_repo.dart';
import 'package:mocktail/mocktail.dart';

class MockAuthRepo extends Mock implements AuthRepo {}
