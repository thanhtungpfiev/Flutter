import 'package:education_app/core/common/features/course/domain/repos/course_repo.dart';
import 'package:mocktail/mocktail.dart';

class MockCourseRepo extends Mock implements CourseRepo {}
