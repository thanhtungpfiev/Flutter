
const kDefaultAvatar = 'https://images.freeimages'
    '.com/fic/images/icons/573/must_have/256/user.png';
