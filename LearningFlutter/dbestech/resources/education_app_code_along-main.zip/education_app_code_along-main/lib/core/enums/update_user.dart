
enum UpdateUserAction {
  displayName,
  email,
  password,
  bio,
  profilePic,
}
